module.exports = {
  "appID" : "amzn1.echo-sdk-ams.app.e85fbdd1-d55d-4a23-a396-9cc7e54bbe43"
}